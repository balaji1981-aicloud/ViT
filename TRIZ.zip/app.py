import os
import re
from typing import TypedDict, List, Dict, Optional
import markdown

# FastAPI + Uvicorn + Templates (Jinja2) + HTMX response
from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

# LangGraph / LangChain
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver

# Use maintained Ollama integration
# pip install -U langchain-ollama
from langchain_ollama import OllamaLLM

# HTTP utilities for tools
import requests
import feedparser

# ------------- LLM (Ollama) -------------
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://10.87.60.30:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "gpt-oss:20b")
llm = OllamaLLM(model=OLLAMA_MODEL, base_url=OLLAMA_BASE_URL, temperature=0.3)

# ------------- Tools -------------
def search_arxiv(query: str) -> str:
    try:
        base_url = "https://export.arxiv.org/api/query"
        params = {"search_query": f"all:{query}", "start": 0, "max_results": 5}
        resp = requests.get(base_url, params=params, timeout=10)
        feed = feedparser.parse(resp.text)
        if not feed.entries:
            return "ARXIV_RESULTS: No results found."
        results = ["ARXIV_RESULTS:"]
        for i, entry in enumerate(feed.entries, 1):
            title = entry.title.strip()
            summary = entry.summary.replace("\n", " ").strip()[:400]
            results.append(
                f"PAPER_{i}:\nTitle: {title}\nURL: {entry.link}\nSummary: {summary}\n---"
            )
        return "\n".join(results)
    except Exception as e:
        return f"ARXIV_RESULTS: Error occurred - {str(e)}"

def search_semanticscholar(query: str) -> str:
    try:
        resp = requests.get(
            "https://api.semanticscholar.org/graph/v1/paper/search",
            params={"query": query, "fields": "title,abstract,url", "limit": 5},
            headers={"User-Agent": "Mozilla/5.0 (compatible; research-bot/1.0)"},
            timeout=10,
        )
        if resp.status_code != 200:
            return f"SEMANTIC_SCHOLAR_RESULTS: API error - Status {resp.status_code}"
        papers = resp.json().get("data", [])
        if not papers:
            return "SEMANTIC_SCHOLAR_RESULTS: No results found."
        results = ["SEMANTIC_SCHOLAR_RESULTS:"]
        for i, p in enumerate(papers, 1):
            title = p.get("title", "Untitled")
            abstract = p.get("abstract", "No abstract available") or "No abstract available"
            abstract = abstract[:400]
            url = p.get("url", "#")
            results.append(
                f"PAPER_{i}:\nTitle: {title}\nURL: {url}\nSummary: {abstract}\n---"
            )
        return "\n".join(results)
    except Exception as e:
        return f"SEMANTIC_SCHOLAR_RESULTS: Error occurred - {str(e)}"

def search_lens_patents(query: str) -> str:
    api_key = os.getenv("LENS_API_KEY", "").strip()
    if not api_key:
        return "LENSON_PATENTS_RESULTS: No results found."
    try:
        headers = {"Authorization": f"Bearer {api_key}"}
        url = "https://api.lens.org/scholarly/search"
        payload = {
            "query": {"query_string": {"query": query}},
            "size": 5,
            "_source": ["title", "abstract", "lens_id"],
        }
        response = requests.post(url, json=payload, headers=headers, timeout=10)
        response.raise_for_status()
        data = response.json()
        items = data.get("data", {}).get("items", [])
        if not items:
            return "LENSON_PATENTS_RESULTS: No results found."
        results = ["LENSON_PATENTS_RESULTS:"]
        for i, item in enumerate(items, 1):
            title = item.get("title", "Untitled")
            abstract = (item.get("abstract") or "No abstract available")[:400]
            lens_id = item.get("lens_id")
            link = f"https://www.lens.org/lens/patent/{lens_id}" if lens_id else "#"
            results.append(
                f"PATENT_{i}:\nTitle: {title}\nURL: {link}\nSummary: {abstract}\n---"
            )
        return "\n".join(results)
    except Exception as e:
        return f"LENSON_PATENTS_RESULTS: Error occurred - {str(e)}"

# ------------- LangGraph Nodes -------------
class WorkflowState(TypedDict, total=False):
    user_query: str
    arxiv_query: Optional[str]
    semanticscholar_query: Optional[str]
    lens_patent_query: Optional[str]
    arxiv_results: Optional[str]
    semanticscholar_results: Optional[str]
    lens_patents_results: Optional[str]
    deduped_evidence: Optional[List[Dict[str, str]]]
    synthesized_evidence: Optional[str]
    triz_solution: Optional[str]

def node_rewrite_queries(state: WorkflowState) -> WorkflowState:
    query = state["user_query"]
    arxiv_prompt = f"Rewrite this research question for a technical arXiv search: '{query}'"
    ss_prompt = f"Rewrite this research question for a technical Semantic Scholar search: '{query}'"
    lens_prompt = f"Rewrite this research question for a Lens.org patent search: '{query}'"

    arxiv_query = llm.invoke(arxiv_prompt)
    ss_query = llm.invoke(ss_prompt)
    lens_query = llm.invoke(lens_prompt)

    return {
        **state,
        "arxiv_query": arxiv_query,
        "semanticscholar_query": ss_query,
        "lens_patent_query": lens_query,
    }

def node_retrieve_arxiv(state: WorkflowState) -> WorkflowState:
    results = search_arxiv(state["arxiv_query"])
    return {**state, "arxiv_results": results}

def node_retrieve_semanticscholar(state: WorkflowState) -> WorkflowState:
    results = search_semanticscholar(state["semanticscholar_query"])
    return {**state, "semanticscholar_results": results}

def node_retrieve_lens_patents(state: WorkflowState) -> WorkflowState:
    results = search_lens_patents(state["lens_patent_query"])
    return {**state, "lens_patents_results": results}

def node_deduplicate_evidence(state: WorkflowState) -> WorkflowState:
    combined: List[Dict[str, str]] = []
    seen = set()
    for source in ["arxiv_results", "semanticscholar_results", "lens_patents_results"]:
        text = state.get(source, "") or ""
        current: Dict[str, str] = {}
        for line in text.split("\n"):
            if line.startswith("Title:"):
                current["title"] = line.replace("Title:", "").strip()
            elif line.startswith("URL:"):
                current["url"] = line.replace("URL:", "").strip()
            elif line.startswith("Summary:"):
                current["summary"] = line.replace("Summary:", "").strip()
            elif line.strip() == "---":
                if current.get("title") and current["title"] not in seen:
                    combined.append(dict(current))
                    seen.add(current["title"])
                current = {}
    return {**state, "deduped_evidence": combined}

def node_summarize_evidence(state: WorkflowState) -> WorkflowState:
    evidence = state.get("deduped_evidence", []) or []
    query = state["user_query"]
    combined_text = "\n\n".join(
        [
            f"{i+1}) Title: {e['title']}\nURL: {e['url']}\nSummary: {e['summary']}"
            for i, e in enumerate(evidence)
        ]
    )

    prompt = f"""
    Based on the following research problem and evidence, extract the key insights for TRIZ analysis.
    Problem: '{query}'
    Evidence:
    {combined_text}

    Synthesize the most critical points into a brief summary.
    """
    summary = llm.invoke(prompt)
    return {**state, "synthesized_evidence": summary}

def node_generate_triz_solution(state: WorkflowState) -> WorkflowState:
    query = state["user_query"]
    evidence_for_triz = state.get("synthesized_evidence", "")
    
    prompt = f"""
    You are a TRIZ Expert AI. Your task is to generate a structured TRIZ solution for the problem: '{query}'.
    Use the provided evidence to inform your solution.

    Evidence: {evidence_for_triz}

    IMPORTANT: Your response must start *directly* with '## Introduction' and follow the template below exactly. Do not add any preamble or evidence text before the first heading.

    ## Introduction
    (Concise paragraph on the core physical contradiction.)

    ## 1. Problem Formulation (Contradiction Identification)
    **Technical Contradiction:** [Define]
    - **Improving Feature:** [Specify]
    - **Worsening Feature:** [Specify]
    **Physical Contradiction:** [Define]
    - **Improving Feature:** [Specify]
    - **Worsening Feature:** [Specify]

    ## 2. Apply TRIZ Inventive Principles
    (Identify at most top five relevant principles with ideas and examples.)

    ## 3. Consider System Separation
    - **Separation in Time:** [Description and example]
    - **Separation in Space:** [Description and example]
    
    ## 4. Move Toward Ideality
    (Brainstorm paths to the Ideal Final Result.)

    ## 5. Real-world Analogies and Examples
    (List 3 analogous systems or industry examples.)

    ## Summary Table
    | TRIZ Principle Application | Implementation                 |
    |----------------------------|--------------------------------|
    | [Principle 1]              | [Summary here]                 |
    | [Principle 2]              | [Summary here]                 |
    | [Other principles]         | [Summaries]                    |

    """
    full_solution = llm.invoke(prompt)
    
    if "## Introduction" in full_solution:
        triz_solution = "## Introduction" + full_solution.split("## Introduction", 1)[1]
    else:
        triz_solution = full_solution

    return {**state, "triz_solution": triz_solution.strip()}


# ------------- Build Graph -------------
workflow = StateGraph(WorkflowState)
workflow.add_node("rewrite_queries", node_rewrite_queries)
workflow.add_node("retrieve_arxiv", node_retrieve_arxiv)
workflow.add_node("retrieve_semanticscholar", node_retrieve_semanticscholar)
workflow.add_node("retrieve_lens_patents", node_retrieve_lens_patents)
workflow.add_node("deduplicate_evidence", node_deduplicate_evidence)
workflow.add_node("summarize_evidence", node_summarize_evidence)
workflow.add_node("generate_triz_solution", node_generate_triz_solution)

workflow.set_entry_point("rewrite_queries")
workflow.add_edge("rewrite_queries", "retrieve_arxiv")
workflow.add_edge("retrieve_arxiv", "retrieve_semanticscholar")
workflow.add_edge("retrieve_semanticscholar", "retrieve_lens_patents")
workflow.add_edge("retrieve_lens_patents", "deduplicate_evidence")
workflow.add_edge("deduplicate_evidence", "summarize_evidence")
workflow.add_edge("summarize_evidence", "generate_triz_solution")
workflow.add_edge("generate_triz_solution", END)

memory = MemorySaver()
graph = workflow.compile(checkpointer=memory)

def run_workflow(user_query: str, thread_id: str) -> Dict[str, str]:
    config = {"configurable": {"thread_id": thread_id}}
    final_state = None
    for state in graph.stream({"user_query": user_query}, config=config):
        final_state = state

    last_message = list(final_state.values())[0] if final_state else {}
    return {
        "triz_solution": last_message.get("triz_solution", "No TRIZ solution generated."),
    }

# ------------- Web App (HTMX UI) -------------
app = FastAPI(title="TRIZ Research Assistant")
app.mount("/static", StaticFiles(directory="static"), name="static")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/", response_class=HTMLResponse)
async def root():
    return """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>TRIZ Assistant</title>
        <script src="https://unpkg.com/htmx.org@1.9.10"></script>
        <link rel="stylesheet" href="/static/styles.css">
        <style>
            /* HTMX loading indicator styles */
            .htmx-indicator {
                display: none;
            }
            .htmx-request .htmx-indicator {
                display: inline;
            }
            .htmx-request .htmx-indicator ~ * {
                display: none;
            }
        </style>
    </head>
    <body>
        <h1>TRIZ Research Assistant</h1>
        <form hx-post="/run" hx-target="#results" hx-swap="innerHTML">
            <input type="text" name="query" placeholder="Enter your research problem..." required>
            <button type="submit">
                <span class="htmx-indicator">Generating...</span>
                <span>Generate</span>
            </button>
        </form>
        <div id="results" class="results-container">
            <p>Enter a research query, and the structured TRIZ solution will appear here.</p>
        </div>
    </body>
    </html>
    """

@app.post("/run", response_class=HTMLResponse)
async def run_workflow_endpoint(query: str = Form(...)):
    thread_id = f"thread_{os.urandom(4).hex()}"
    results = run_workflow(query, thread_id)
    
    triz_solution_md = results.get("triz_solution", "An error occurred or no solution was generated.")
    
    triz_solution_html = markdown.markdown(triz_solution_md, extensions=['tables'])

    return HTMLResponse(content=f"""
    <div id="results" class="results-container" hx-swap-oob="true">
        {triz_solution_html}
    </div>
    """)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
