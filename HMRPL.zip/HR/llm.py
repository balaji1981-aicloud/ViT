import subprocess
import pandas as pd
import yaml
import re
import subprocess
import tempfile
import os
from langchain_core.prompts import PromptTemplate
from langchain_core.language_models import LLM
from langchain_core.output_parsers import StrOutputParser
from ollama import Client
import json

class OllamaClientLLM(LLM):
    client: Client
    model: str = "gpt-oss:20b"

    @property
    def _llm_type(self) -> str:
        return "ollama_client_wrapper"

    def _call(self, prompt: str, stop=None):
        response = self.client.chat(
            model=self.model,
            messages=[{"role": "user", "content": prompt}]
        )
        return response["message"]["content"]

attendance_path = r"C:\Users\Y8664226\Downloads\HR\attendance.xlsx"
components_path = r"C:\Users\Y8664226\Downloads\HR\components.xlsx"
yaml_path = r"C:\Users\Y8664226\Downloads\HR\payroll_config.yaml"

ollama_client = Client(host='http://10.87.60.30:11434')

attendance = pd.read_excel(attendance_path)
components = pd.read_excel(components_path)


attendance_csv_text = attendance.to_csv(index=False)
component_csv_text = components.to_csv(index=False)

with open(yaml_path, "r") as f:
    yaml_text = f.read()


coder_prompt = PromptTemplate(
    input_variables=["attendance_csv", "components_csv", "yaml_config"],
    template="""
You are an expert Python automation engineer.

You are given:
- attendance.xlsx content
- components.xlsx content
- YAML config that defines ALL payroll rules and logic

Your job:
Generate Python code that:

1. Loads both CSVs (we pass them as strings)
2. Loads the YAML config (passed as text)
3. Dynamically interprets ALL payroll rules from YAML  
   - No fixed formulas  
   - No assumptions  
   - No invented logic  
   - Every calculation must come ONLY from YAML instructions
4. Applies the YAML-defined rules to compute payroll fields
5. Produces a final CSV file named **final_payroll.xlsx**
6. can have logging statements to help debugging
Strict rules:
- Do NOT invent numbers
- Do NOT create formulas on your own
- Derive ALL computation steps exclusively from the YAML definition
- Missing values = 0
- Output ONLY valid Python code inside:

```python
# code here
````
Attendance CSV:
{attendance_csv}

Salary Components CSV:
{components_csv}


YAML:
{yaml_config}
"""
)
validator_prompt = PromptTemplate(
    input_variables=["yaml_config", "generated_code", "script_output"],
    template="""
You are a specific quality assurance robot. 
You do NOT write code. You only output JSON.

Task: Validate the Python payroll script against the YAML rules.

Input Context:
1. YAML Rules: {yaml_config}
2. Python Code: {generated_code}
3. Execution Output: {script_output}

Instructions:
- Check if the code strictly follows the YAML.
- Check if the calculated values in Output match the formulas in YAML.
- If the code logic is wrong (e.g., creating formulas not in YAML), mark is_valid as false.

RESPONSE FORMAT:
You must output ONLY a single JSON object. 
Do not wrap it in python blocks. 
Do not add explanations outside the JSON.

JSON Structure:
{{
  "is_valid": boolean,
  "errors": ["list of specific error strings"],
  "feedback": "detailed instructions on how to fix the code logic",
  "summary": "brief summary"
}}

If the code is wrong, put the corrected logic text INSIDE the "feedback" field of the JSON.

RESPONSE:
"""
)


def extract_python_code(raw_text: str) -> str:

    match = re.search(r"```(?:python)?\s*(.*?)\s*```", raw_text, re.DOTALL)
    return match.group(1).strip() if match else raw_text.strip()

def extract_json(raw_text):
    raw_text = re.sub(r"<think>.*?</think>", "", raw_text, flags=re.DOTALL).strip()

    match = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", raw_text, re.DOTALL)
    if match:
        return match.group(1).strip()
    start_index = raw_text.find('{')
    end_index = raw_text.rfind('}')
    
    if start_index != -1 and end_index != -1 and end_index > start_index:
        return raw_text[start_index : end_index + 1]

    return None
    

def save_code_to_file(code_str: str, filename: str):

    with open(filename, "w", encoding="utf-8") as f:
        f.write(code_str)
    print(f"[INFO] Script saved: {filename}")
    
def run_python_script(filename: str):

    if not os.path.exists(filename):
        return None, f"[ERROR] File not found: {filename}", -1

    print(f"[INFO] Running: {filename}")

    process = subprocess.Popen(
        ["python", filename],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )

    stdout, stderr = process.communicate()
    return stdout, stderr, process.returncode

def remove_think(s: str):
    return re.sub(r"<think>.*?</think>", "", s, flags=re.DOTALL).strip()
#======================================================================

coder_llm = OllamaClientLLM(
client=ollama_client,
model="gpt-oss:20b",
temperature=0
)

code_chain = coder_prompt | coder_llm | StrOutputParser()

raw_code = code_chain.invoke({
"attendance_csv": attendance_csv_text,
"components_csv": component_csv_text,
"yaml_config": yaml_text,
})

validator_llm = OllamaClientLLM(
    client=ollama_client,
    model="gpt-oss:20b",
    temperature=0
)

validator_chain = validator_prompt | validator_llm | StrOutputParser()

code = remove_think(raw_code)
clean_code = extract_python_code(code)

print("\n=============== GENERATED PYTHON CODE ===============\n")
# print(clean_code)
debugger_prompt = PromptTemplate(
    input_variables=["code", "error_message"],
    template="""
You are an expert Python Debugger. 
The code below failed to execute.

Your Goal: Fix the specific error reported in the stderr.
- Fix Syntax Errors, Indentation Errors, or Missing Imports.
- Fix Runtime Errors (KeyError, ValueError, TypeErrors).
- Do NOT change the business logic or formulas; only fix the code structure so it runs.

Broken Code:
```python
{code}
Error Message (stderr): {error_message}

Output ONLY the fixed Python code inside python block. """
)

debugger_chain = debugger_prompt | coder_llm | StrOutputParser()

script_file = "generated_payroll.py"
# save_code_to_file(clean_code, script_file)
MAX_ITERATIONS = 5
iteration = 1

current_code = clean_code  # first generated code

while iteration <= MAX_ITERATIONS:

    print(f"\n\n========================= ITERATION {iteration} =========================\n")
    save_code_to_file(current_code, script_file)
    run_stdout, run_stderr, run_returncode = run_python_script(script_file)

    print("\n=============== SCRIPT OUTPUT ===============\n")
    print("stdout:")
    print(run_stdout)
    print("\nstderr:")
    print(run_stderr)

    if run_returncode != 0:
            print(f"\n[CRITICAL] Script crashed with exit code {run_returncode}")
            print("--> Sending to DEBUGGER...")
            
            debug_raw = debugger_chain.invoke({
                "code": current_code,
                "error_message": run_stderr
            })
            
            # Extract and update code
            fixed_code = extract_python_code(remove_think(debug_raw))
            print("\n[INFO] Debugger generated a fix. Retrying...\n")
            
            current_code = fixed_code
            iteration += 1
            continue  # Skip validation, go straight to running the fixed code

        # =====================================================
   
    print("\n[SUCCESS] Script ran successfully. Validating Logic...\n")

    if os.path.exists("final_payroll.xlsx"):
        try:
            df_out = pd.read_excel("final_payroll.xlsx")
            script_output = df_out.to_csv(index=False)
        except:
            script_output = "final_payroll.xlsx exists but could not be read."
    else:
        script_output = run_stdout
    validation_raw = validator_chain.invoke({
        "yaml_config": yaml_text,
        "generated_code": current_code,
        "script_output": script_output
    })

    validation_clean = remove_think(validation_raw)

    print("\n=============== VALIDATION REPORT ===============\n")

    raw_json = extract_json(validation_clean)
    if raw_json is None:
        print("[ERROR] No JSON found in validator response.")
        print(validation_clean)
        break
    print(raw_json)
    try:
        validation_json = json.loads(raw_json)
    except:
        print("[ERROR] Validator returned non-JSON output. Aborting.")
        break
    if validation_json.get("is_valid", False):
        print("\n VALIDATION PASSED — FINAL PAYROLL IS CORRECT \n")
        break

    print("\nValidation failed — regenerating code using validator feedback...\n")

    feedback = validation_json.get("feedback", "")
    error_list = validation_json.get("errors", [])

    refine_prompt = PromptTemplate(
    input_variables=["feedback_summary", "attendance_csv", "components_csv", "yaml_config"],
        template="""
The validation found issues in the generated code.

feedback summary:
{feedback_summary}


Attendance CSV:
{attendance_csv}

Components CSV:
{components_csv}

YAML:
{yaml_config}

Fix the Python code accordingly. Use ONLY YAML rules and correct the logic.
Output only corrected python code in ```python``` block.

Strict rules:
- Do NOT invent numbers, dont not change or manipulate any numbers from the both csv
- Do NOT create formulas on your own
- Derive ALL computation steps exclusively from the YAML definition
- Missing values = 0
- Output ONLY valid Python code inside:
""" 
)

    code_refine = refine_prompt | coder_llm | StrOutputParser()

    corrected_raw = code_refine.invoke({
        "feedback_summary": json.dumps({
            "feedback": feedback,
            "errors": error_list
        }),
        "attendance_csv": attendance_csv_text,
        "components_csv": component_csv_text,
        "yaml_config": yaml_text
    })

    corrected_raw = remove_think(corrected_raw)
    corrected_code = extract_python_code(corrected_raw)

    print("\n=============== CORRECTED CODE ===============\n")
    # print(corrected_code)

    current_code = corrected_code
    iteration += 1


if iteration > MAX_ITERATIONS:
    print("\n❌ Max iterations reached — failed to converge.\n")

